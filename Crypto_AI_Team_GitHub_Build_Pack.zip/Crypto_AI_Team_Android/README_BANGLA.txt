Crypto AI Team Android starter project
======================================

এতে যা আছে:
- Android app source project (Kotlin + WebView)
- Binance public API থেকে BTC, ETH, BNB, SOL-এর live 24h ticker
- ৬টি specialist agent-এর UI এবং Chief Analyst-এর simple data summary
- API key লাগে না, তবে internet লাগে

সত্যি কথা:
- এটি এখনো compiled APK নয়; এটি APK বানানোর source project।
- ৬টি agent-এর বাস্তব AI-to-AI debate এখনো যোগ হয়নি। সেটির জন্য AI model/service বা নিজস্ব backend দরকার।
- Android APK তৈরি করতে Android Studio/Gradle build environment দরকার।

Android Studio দিয়ে build:
1. ZIP extract করুন।
2. Android Studio-তে Open দিয়ে Crypto_AI_Team_Android folder নির্বাচন করুন।
3. Gradle sync শেষ হতে দিন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
5. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ থাকবে।

Free live market data Binance-এর public endpoint ব্যবহার করে। Endpoint/region/network অনুযায়ী access বদলাতে পারে।
